package com.example.proyectodbp.Model;

public class Producto {
    private int idProducto;
    private String descripcionProdcuto;
    private double precioProducto;
    private int stockProducto;
    private int idCategoria;

    public Producto(int idProducto, String descripcionProducto, double precioProdcuto, int stockProducto, int idCategoria) {
        this.idProducto = idProducto;
        this.descripcionProdcuto = descripcionProdcuto;
        this.precioProducto = precioProducto;
        this.stockProducto = stockProducto;
        this.idCategoria = idCategoria;
    }
    public Producto(){

    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getDescripcionProdcuto() {
        return descripcionProdcuto;
    }

    public void setDescripcionProdcuto(String descripcionProdcuto) {
        this.descripcionProdcuto = descripcionProdcuto;
    }

    public double getPrecioProducto() {
        return precioProducto;
    }

    public void setPrecioProducto(double precioProducto) {
        this.precioProducto = precioProducto;
    }

    public int getStockProducto() {
        return stockProducto;
    }

    public void setStockProducto(int stockProducto) {
        this.stockProducto = stockProducto;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }
}
